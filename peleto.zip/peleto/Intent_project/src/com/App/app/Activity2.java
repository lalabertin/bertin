package com.App.app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

public class Activity2 extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_activity2);
		setContentView(R.layout.activity_activity2);
		final Button switchat=(Button)findViewById(R.id.btn2);
		switchat.setOnClickListener(new View.OnClickListener()
		{
			@SuppressWarnings("unused")
			public void onclick(View view){
				Intent act1=new Intent(view.getContext(),Activity1.class);
				startActivity(act1);
			}

			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				
				Intent act1=new Intent(arg0.getContext(),Activity1.class);
				startActivity(act1);
				
			}
			
		});
			

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.activity2, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
