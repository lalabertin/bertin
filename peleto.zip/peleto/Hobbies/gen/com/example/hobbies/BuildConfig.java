/** Automatically generated file. DO NOT MODIFY */
package com.example.hobbies;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}