package com.example.form_app;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;


public class MainActivity extends Activity {
	Button Ctxt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Ctxt =(Button) findViewById(R.id.TX_1);
        registerForContextMenu(Ctxt);
        @SuppressWarnings("unused")
        Button Ctxt= (Button) findViewById(R.id.TX_1);
    	Button btnclose = (Button) findViewById(R.id.btncloses);
    	btnclose.setOnClickListener(new OnClickListener() {
    		@Override
    		public void onClick(View arg0){
    			finish();
    			System.exit(0);
    			
    		}
    	});
 
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu){
		getMenuInflater().inflate(R.menu.main, menu);
    	
    	return true;
    	    }
    public boolean onOptionsItemSelected(MenuItem item){
    	switch (item.getItemId())
    	{
    		case R.id.btncloses:
    			finish();
    			System.exit(0);
    			default:
    				return super.onOptionsItemSelected(item);
    	
    
    }
    }
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, 
    		ContextMenuInfo MenuInfo){
    	
    	super.onCreateContextMenu(menu, v, MenuInfo);
    	MenuInflater inflater = getMenuInflater();
    	 inflater.inflate(R.menu.main, menu);
    	
    	    }
    @Override
    public boolean onContextItemSelected(MenuItem item){
    	switch (item.getItemId())
    	{
    	case R.id.btncloses:
    		finish();
    		System.exit(0);
    		default:
		return super.onContextItemSelected(item);}
	}
    public class Activity1 extends Activity {
    	 
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
     
            final Button switchact =(Button)findViewById(R.id.Home3);
            switchact.setOnClickListener(new View.OnClickListener() {
     
                @Override
                public void onClick(View view) {
                    Intent act2 = new Intent(view.getContext(),MainActivity.class);
                    startActivity(act2);
     
                }
            });
    }}
}
	

    