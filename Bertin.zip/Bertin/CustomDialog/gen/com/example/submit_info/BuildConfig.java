/** Automatically generated file. DO NOT MODIFY */
package com.example.submit_info;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}